//
//  StreamLogoAnimationApp.swift
//  StreamLogoAnimation
//
//  Created by amos.gyamfi@getstream.io on 3.12.2021.
//

import SwiftUI

@main
struct StreamLogoAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            StreamLogo()
        }
    }
}
